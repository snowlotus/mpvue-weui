# webpack 简介
## webpack概述
A bundler for javascript and friends. Packs many modules into a few bundled assets. Code Splitting allows to load parts for the application on demand. Through "loaders," modules can be CommonJs, AMD, ES6 modules, CSS, Images, JSON, Coffeescript, LESS, ... and your custom stuff

webpack就是一个js的打包器。
将各种各样的资源打包成静态文件。
如果项目中需要实现资源的按需加载，可以使用webpack的代码分割功能。
通过loaders，可以打包各种各样的模块，eg：CommonJs, AMD, ES6 modules, CSS, Images, JSON, Coffeescript, LESS...或者任何你自定义的模块




## webpack版本迭代&功能进化
[正式版本releases](https://github.com/webpack/webpack/releases)


* v1.0.0--- 2014.2.20   编译、打包、HMR、代码分割、文件处理
* v2.2.0--- 2017.1.18   Tree Shaking、ES module、动态Import、新的官方文档
* v3.0.0--- 2017.6.19   Scope Hoisting 、magic Comments
* v4.0.0--- 2018.2.25   webpack-cli 、mode、零配置、SplitChunksPlugin、构建速度up（90%+）
* v4.23.1 ---current（2018.10.18）
* v5.x--- 移除ExtractTextWebpackPlugin插件，并支持CSS模块类型、持久化缓存


HMR：不刷新页面就可以看到代码更新
code spliting: 将代码分割成chunks（语块），当代码运行到需要它们的时候再加载
Tree shaking:引用到项目中的代码，但实际并没有用到的代码给删除掉，使打包后的代码体积更小
scope hoisting：并非打包的速度提升，而是打包后的代码的运行性能的提升。把所有模块的代码提升到单一的作用域中，减少闭包（闭包越多，浏览器的运行效率越低）
magic comments：配合动态import来使用，来指定打包后的代码chunk的名称叫什么

## webpack 版本迁移

[v1->v2](https://webpack.docschina.org/guides/migrating/)
[v2->v3](https://webpack.docschina.org/migrate/3/)
*v2->v3的升级 比v1-v2升级简单很多*
v3-->v4.TODO ??

##TODO 名词解释
chunk：代码块。
bundle：一捆；已经打包好在一起的代码
module：模块。一个个文件转化成模块


## webpack 核心概念
entry
output
loaders
plugins

### entry
代码的入口
打包的入口
（告诉webpack从哪个文件去找代码的依赖，以及依赖的依赖）
单个或多个
（多个的情况：多页面应用程序或者单页面应用中将业务代码放到一个entry；将框架代码放到另一个entry）

TODO 借助例子

### output

对打包生成文件的描述
一个或多件
自定义规则
配合cdn

TODO 借助例子

### loaders
处理文件
把各种文件转化为js模块，在js中可以直接引入

#### 常用loader
##### 编译相关
 babel-loader ts-loader
 ##### 样式相关
 style-loader css-loader less-loader postcss-loader
#### 文件相关
file-loader url-loader

[更多loader](https://webpack.docschina.org/loaders/)

### TODO plugins
参与打包整个过程
打包优化与压缩
配置编译时的变量

#### 常用plugins
##### 优化相关
commonsChunkPlugin  提取不同chunks之间相同代码到一个独立的文件
UglifyjsWebpackPlugin 混淆压缩js代码及js sourcemap

##### 功能相关
ExtractTextWebpackPlugin  将css提取到一个单独文件
HtmlWebpackPlugin   生成html
HotModuleReplacementPlugin  模块热更新
CopyWebpackPlugin  拷贝文件

[更多plugins](https://webpack.docschina.org/plugins/)

## webpack 使用

### TODO  命令行 webpack-cli 介绍？？？
初始化一个项目
迁移项目 v1->v2

### TODO webpack 配置
编写js文件，在命令行中使用webpack命令，或者在package.json中指定npm命令关联webpack文件

### 脚手架
vue-cli
angular-cli
create-react-app

## 实际动手
### 打包js
3-2 分别用es6 moudle、commonjs、amd的方式引入模块，通过**命令行以及配置文件**的方式看打包的结果
tips：引入amd规范的模块时，最后打包出的文件会多一个bundle，因为amd是异步加载的模块

### 编译es6/7 (TODO 此部分需要好好再回顾下)
#### TODO babel-presets:babel规范的总结 
规范集合如下
* es2015
* es2016
* es2017 
* env（包含了es2015到2017 以及最新的babel规范）
* babel-preset-react
* babel-preset-stage 0-3（未发布的几个阶段的规范）
targets：编译后的目标
targets
targets.browsers:"last 2 versions / >1%"
browserslist
can i use

### babel polyfill & babel-transform-runtime
以下函数和方法  babel-loader无法处理，需要借助babel polyfill
Generator
Set
Map
Array.from
Array.prototype.includes

#### babel polyfill
浏览器对es6标准的实现不一致，使用polyfill垫片保持api的一致
特点：全局垫片 、为应用准备（而非框架）
npm install babel-polyfill --save

#### babel-transform-runtime
特点：局部垫片，为开发框架而准备
npm install babel-plugin-transform-runtime --save-dev
npm install babel-runtime --save
.babelrc


3-3 npm install babel-loader @babel/core @babel/preset-env --save-dev
app.js es6的相关语法 let const 箭头函数 map／set

1.配置webpack文件，use babel-loader配置js文件的编译 ,此时includes、set没有被编译
2.安装polyfill
3.安装runtime


### html in webpack
自动化生成html
场景优化
将manifest插入到html中

#### TODO生成html
htmlWebpackPlugin
options
    template
    filename
    minify
    chunks
    inject

### 开发环境搭建
 
webpack watch mode
webpack-dev-server
express+webpack-dev-middleware
环境区分

#### webpack watch mode
没有开启服务及监听端口，只能自己访问
webpack watch
webpack -w

#### webpack-dev-server
TODO 带领大家熟悉下api
tips：官方提供，在本地环境搭建web 服务器
1.打包文件？NO （代码在内存中，dist目录下没有）
2.live reloading／路径重定向／https／浏览器中显示编译错误
3.proxy （TODO 介绍proxy）
4.模块热更新  （TODO介绍 HMR）


#### source map调试
Devtool
webpack.sourceMapDevToolPlugin
webpack.EvalSourceMapDevToolPlugin

#### 环境区分
    TODO 用一个表格列出两个的共同点，不同点

如何做？
    webpack-merge
    webpack.dev.conf.js
    webpack.prod.conf.js
    webpack.base.conf.js





### webpack 优化
#### 打包速度优化
    影响因素：文件多、依赖多、页面多（业务逻辑）
    方法：
    1. 分开vendor 和 app （vendor不常改动，把它抽出来，不用每次都参与打包）
        通过DllPlugin和DllReferencePlugin 指定已提前打包好的第三方文件
    2. 通过UglifyJsPlugin 的parallel  并行处理js的压缩、混淆
    3. happypack 将loader的串行处理变成并行
    4. babel-loader ：开启缓存、规定include& exclude
    5. 减少resolve查找时间；prod环境去除sourcemap（sourcemap的生成也是耗时的）
    6. 升级node、webpack

    总结：能并行处理的任务尽量并行（通过UglifyJsPlugin和happypack）；尽可能减少处理任务的范围；尽可能利用缓存；新版本的跟进

#### 长缓存优化
TODO what is 长缓存？
TODO why use 长缓存？
how to do ？

场景
    改变app代码，vendor变化

解决
    提取 vendor
    hash -> chunkhash
    提取 webpack runtime


### vue和webpack（17）
    
开发配置
base：
基础配置，供dev、prod、test使用，包含4个部分
1.依赖声明
2.resolve函数，获取文件的路径
3.eslint loader的配置
4.基础配置 
    context：整个运行环境的上下文 （项目根目录）
    extensions：引入相应的文件，无需加入后缀
    vue$:表示vue后面不能再跟其他的路径，vue是确切的指向后面配置的目录
    modules：各种loader规则
TODO vue-loader.conf.js
    所有vue-loader相关的配置


TODO utils.js
assetsPath:path.posix  跨平台使用的
cssLoaders： 定义了两个lo
styleLoaders：函数，输入options，输出output

### react和webpack
TODO 功能点

### webpack 4
mode：区分场景 none/dev/pro
零配置
optimization.splitChunks 替commonChunksPlugin
optimization.minimizer (废弃uglifyjs)
打包速度提高90% 

### webpack 未来
TODO 找到以下这些特性的来源
css成为原生模块
html 成为原生 模块
URL／File 成为原生模块
不再需要extract-text-webpack-plugin
不需要css／file／url loader
css code splitting
html entry（通过html entry查找页面依赖的资源来进行打包）




























